package dashbord.DAO;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class Database {

        static String url="jdbc:mysql://localhost:3306/cardiosafe";
        static String name="root";
        static String pw= null;


    private static Database instance = new Database();

    private  Connection conn;
    private  ResultSet rs;
    private  Statement st;

    public static  Database getInstance() {
        return instance;
    }



    public void connect() throws ClassNotFoundException, SQLException {
        if (conn != null)
            return;

        Class.forName("com.mysql.jdbc.Driver"); // Load the driver

        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/", name, pw); // Establish connection to MySQL server without specifying a database
        st = conn.createStatement(); // Create statement

        // Create the database if it doesn't exist
        st.executeUpdate("CREATE DATABASE IF NOT EXISTS cardiosafe");

        conn = DriverManager.getConnection(url, name, pw); // Connect to the specified database
        st = conn.createStatement(); // Create statement for the specific database

        st.executeUpdate("CREATE TABLE IF NOT EXISTS Abonne (id INT AUTO_INCREMENT PRIMARY KEY, nom VARCHAR(255), prenom VARCHAR(255), date VARCHAR(255), type VARCHAR(255))");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS Allergy (allergyId INT AUTO_INCREMENT PRIMARY KEY, allergyName VARCHAR(255))");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS Consultation ("
                + "consultationId INT AUTO_INCREMENT PRIMARY KEY, "
                + "type VARCHAR(255), "
                + "description TEXT, "
                + "diagnostics TEXT, "
                + "consultationDate TIMESTAMP, "
                + "status VARCHAR(255), "
                + "prix INT, "
                + "patient_FullName VARCHAR(255)"
                + ")");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS Drug ("
                + "drugId INT AUTO_INCREMENT PRIMARY KEY, "
                + "drugName VARCHAR(255), "
                + "drugDescription TEXT"
                + ")");

        st.executeUpdate("CREATE TABLE IF NOT EXISTS Patient ("
                + "patientId INT AUTO_INCREMENT PRIMARY KEY, "
                + "name VARCHAR(255), "
                + "lastName VARCHAR(255), "
                + "telephone VARCHAR(255), "
                + "birthDate DATE, "
                + "address VARCHAR(255), "
                + "city VARCHAR(255), "
                + "sexe VARCHAR(10), "
                + "cin VARCHAR(20), "
                + "credit DOUBLE"
                + ")");

        st.executeUpdate("CREATE TABLE IF NOT EXISTS PatientInfo ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "property VARCHAR(255), "
                + "value TEXT, "
                + "dateAdded DATE"
                + ")");

        st.executeUpdate("CREATE TABLE IF NOT EXISTS Payment ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "amount DOUBLE, "
                + "patient_FullName VARCHAR(255), "
                + "credit VARCHAR(255), "
                + "date DATE, "
                + "patientId INT, "
                + "FOREIGN KEY (patientId) REFERENCES Patient(patientId)"
                + ")");

        st.executeUpdate("CREATE TABLE IF NOT EXISTS Reminder ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "description TEXT, "
                + "date DATE, "
                + "patientId INT, "
                + "FOREIGN KEY (patientId) REFERENCES Patient(patientId)"
                + ")");

        st.executeUpdate("CREATE TABLE IF NOT EXISTS Reservation ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "nom VARCHAR(255), "
                + "prenom VARCHAR(255), "
                + "heure VARCHAR(255), "
                + "type VARCHAR(255)"
                + ")");


        System.out.println("Connected to database");
    }



    public  ResultSet query(String q) {

        try {
            connect();
            st = conn.createStatement();
            rs = st.executeQuery(q);
            System.out.println(rs);

        } catch (Exception e) {
            System.err.println("Error Message : problem in query() method." + e);
        }

        return rs;
    }


    public  int maj(String query)  {

        try {
            connect();
            st = conn.createStatement();
            int rss = st.executeUpdate(query);
            return rss;

        } catch (Exception e) {
            System.err.println("Error Message : problem in maj() method." + e);
        }

        return 0;
    }


    public  int dmlQuery(String q) {
        try {
            connect();
            st = conn.createStatement();
            return st.executeUpdate(q, Statement.RETURN_GENERATED_KEYS);

        } catch (Exception e) {
            System.err.println("Error Message : problem in dmlQuery() method."+e);
        }

        return 0;
    }

    public  int dmlQuery2(String q) {
        try {
            connect();
            int insertedId = 0;
            st = conn.createStatement();
            int num = st.executeUpdate(q, Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = st.getGeneratedKeys();
            if (rs.next()){
                insertedId=rs.getInt(1);
            }
            return insertedId;

        } catch (Exception e) {
            System.err.println("Error Message : problem in dmlQuery() method." + e);
        }

        return 0;
    }

    public void disconnect() {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("Can't close connection" + e);
            }
        }

        conn = null;
    }


}


