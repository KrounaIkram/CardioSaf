package dashbord.DAO;

import dashbord.models.Abonne;
import dashbord.models.Patient;
import dashbord.models.Reservasion;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {

    public List<Reservasion> all() {
        List<Reservasion> reservations = new ArrayList<>();

        String findAllQuery = "SELECT * FROM reservation;";
        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {
            if (rs != null) {
                while(rs.next()) {
                    Reservasion reservation = new Reservasion();
                    reservation.setId(rs.getInt("id"));
                    reservation.setNom(rs.getString("nom_patient"));
                    reservation.setPrenom(rs.getString("prenom_patient"));
                    reservation.setHeure(rs.getString("heure"));
                    reservation.setType(rs.getString("type"));

                    reservations.add(reservation);
                }
            } else {
                System.out.println("ResultSet is null. No data retrieved from the database.");
            }
        } catch (Exception ex) {
            System.out.println("Problem in all - ReservationDAO: " + ex.getMessage());
            ex.printStackTrace(); // Print the stack trace for detailed error analysis
        }

        return reservations;
    }

    public boolean create(Reservasion r) {
        String insertQuery = "INSERT INTO reservation (nom_patient, prenom_patient, type, heure) VALUES ("
                + "'" + r.getNom() + "', "
                + "'" + r.getPrenom() + "', "
                + "'" + r.getType() + "', "
                + "'" + r.getHeure() + "');";


        r.setId(Database.getInstance().dmlQuery2(insertQuery));
        return (r.getId() !=0);
    }

}
