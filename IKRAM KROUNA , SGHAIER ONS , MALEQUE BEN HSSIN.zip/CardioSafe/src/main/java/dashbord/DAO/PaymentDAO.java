package dashbord.DAO;

import dashbord.models.Payment;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {

    public Payment find(String id) {
        Payment payment = new Payment();
        PatientDAO patientDAO = DAOFactory.getPatientDAO();

        String findQuery = "SELECT * "
                + "FROM payment "
                + "WHERE id = " + Integer.parseInt(id) + ";";

        ResultSet rs = Database.getInstance().query(findQuery);

        try {

            rs.first();
            payment.setId(Integer.parseInt(id));
            payment.setAmount(rs.getDouble("amount"));
            payment.setDate(rs.getDate("date"));
            payment.setPatient(patientDAO.find(rs.getString(id)));
            payment.setCredit(String.valueOf(payment.getPatient().getCredit()));


        } catch (SQLException ex) {
            System.out.println("Error : PaymentDAO.find()" + ex);
        }

        return payment;
    }


    public boolean create(Payment p) {

        String insertQuery = "INSERT INTO payment(amount, date, patientId) VALUES("
                + p.getAmount() + ", "
                + "now(), "
                + p.getPatient().getPatientId() + ");";

        p.setId(Database.getInstance().dmlQuery2(insertQuery));
        return (p.getId()!=0);
    }


    public boolean update(Payment p) {

        String updateQuery = "UPDATE payment "
                + "SET amount = " + p.getAmount()+ ", "
                + "date = '" + p.getDate()+ "', "
                + "patientId = " + p.getPatient().getPatientId() + " "
                + "WHERE id = " + p.getId() + ";";

        return (Database.getInstance().dmlQuery(updateQuery) != 0);
    }


    public boolean delete(Payment p) {

        String deleteQuery = "DELETE FROM payment "
                + "WHERE id = " + p.getId() + ";";

        return (Database.getInstance().dmlQuery(deleteQuery) != 0);
    }



    public List<Payment> all() {

        List<Payment> payments = new ArrayList<>();
        PatientDAO patientDAO = DAOFactory.getPatientDAO();


        String findQuery = "SELECT * "
                + "FROM payment order by date desc;";

        ResultSet rs = Database.getInstance().query(findQuery);

        try {

            while(rs.next()) {

                Payment p = new Payment();

                p.setId(rs.getInt("id"));
                p.setAmount(rs.getDouble("amount"));
                p.setDate(rs.getDate("date"));
                p.setPatient(patientDAO.find(rs.getString("patientId")));
                p.setPatient_FullName(p.getPatient().getName()+" "+ p.getPatient().getLastName());
                p.setCredit(String.valueOf(p.getPatient().getCredit()));


                payments.add(p);
            }

        } catch (SQLException ex) {
            System.out.println("Error : PaymentDAO.all()" + ex);
        }

        return payments;
    }


    public List<Payment> like(String like ) {

        List<Payment> payments = new ArrayList<>();
        PatientDAO patientDAO = DAOFactory.getPatientDAO();


        String findQuery = "select id , amount , date , b.patientId , nom_patient, prenom_patient from patient a , payment b " +
                "where a.id_patient=b.patientId and (prenom_patient like '%" + like + "%' or nom_patient like '%" + like + "%' ) " +
                ";";

        ResultSet rs = Database.getInstance().query(findQuery);

        try {

            while(rs.next()) {

                Payment p = new Payment();

                p.setId(rs.getInt("id"));
                p.setAmount(rs.getDouble("amount"));
                p.setDate(rs.getDate("date"));
                p.setPatient(patientDAO.find(rs.getString("patientId")));
               p.setPatient_FullName(p.getPatient().getName()+" "+ p.getPatient().getLastName());
                p.setCredit(String.valueOf(p.getPatient().getCredit()));


                payments.add(p);
            }

        } catch (SQLException ex) {
            System.out.println("Error : PaymentDAO.all()" + ex);
        }

        return payments;
    }


}
