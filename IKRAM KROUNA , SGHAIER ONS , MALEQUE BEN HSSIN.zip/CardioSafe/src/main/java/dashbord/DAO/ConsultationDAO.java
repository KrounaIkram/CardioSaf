package dashbord.DAO;

import dashbord.models.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ConsultationDAO {
    public Consultation find(String id) {

        Consultation con = new Consultation();

        //PatientDAO patientDAO = DAOFactory.getPatientDAO();
        //PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

        String findQuery = "SELECT * FROM consultation"
                + " WHERE consultationId =" + id + ";";

        ResultSet rs = Database.getInstance().query(findQuery);

        try {
            rs.next();
            con.setConsultationId(rs.getInt("consultationId"));
            con.setType(rs.getString("type"));
            con.setDescription(rs.getString("description"));
            con.setConsultationDate(rs.getTimestamp("consultationDate"));
            con.setStatus(rs.getString("status"));
            con.setPrix(rs.getInt("prix"));
            con.setDiagnostics(rs.getString("diagnostics"));
            //con.setPatient(patientDAO);
            con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
            //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
            con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
        } catch (Exception ex) {
            System.out.println("Problem in find - ConsultationDAO" + ex);
        }

        return con;
    }



    public List<Consultation> all() {

        List<Consultation> consultations = new ArrayList<>();
        //PatientDAO patientDAO = DAOFactory.getPatientDAO();
        //PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

        String findAllQuery = "SELECT * FROM consultation;";
        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();

                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                con.setDiagnostics(rs.getString("diagnostics"));
                //con.setPatient(patientDAO.find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
                consultations.add(con);
            }

        } catch (Exception ex) {
            System.out.println("Problem in all - ConsultationDAO" + ex);
        }

        return consultations;
    }



    public boolean create(Consultation con) {
        String insertQuery = "INSERT INTO consultation(type, description, "
                + "diagnostics, consultationDate, status, prix, patient_FullName) VALUES("
                + "'" + con.getType()               + "', "
                + "'" + con.getDescription()        + "', "
                + "'" + con.getDiagnostics()        + "', "
                + "'" + con.getConsultationDate()   + "', "
                + "'" + con.getStatus()             + "', "
                + con.getPrix()                     + ", "
                + "Ikram Krouna"  + ");";

        con.setConsultationId(Database.getInstance().dmlQuery2(insertQuery));
        return (con.getConsultationId()!=0);
    }



    public boolean update(Consultation con) {
        String updateQuery = "UPDATE consultation"
                + "SET type = " + "'" + con.getType() + "', "
                + "description = '" + con.getDescription().replaceAll("'","\"") + "', "
                + "diagnostics = '" + con.getDiagnostics().replaceAll("'","\"")+ "', "
                + "consultationDate = '" + con.getConsultationDate()+ "', "
                + "status = '" + con.getStatus() + "', "
                + "prix = '" + con.getPrix() + "', "
                //+ "id_patient = '" + con.getPatient().getPatientId() + "' "
                + "WHERE consultationId = '" + con.getConsultationId() + "';";

        return (Database.getInstance().dmlQuery(updateQuery) != 0);
    }



    public boolean delete(Consultation con) {
        String deleteQuery = "DELETE FROM consultation "
                + "WHERE consultationId = " + con.getConsultationId()+ ";";

        return Database.getInstance().dmlQuery(deleteQuery) != 0;
    }


    public boolean introduit(Consultation con, Drug drug) {
        String introduceQuery = "INSERT INTO introduit VALUES("
                + con.getConsultationId() + ", " + drug.getDrugId() + ", '" + drug.getDrugDescription()
                + "');";

        return (Database.getInstance().dmlQuery(introduceQuery) != 0);
    }


    public boolean contient(Consultation con, PatientInfo pInfo) {
        String insertQuery = "INSERT INTO contient VALUES("
                + con.getConsultationId() + ", " + pInfo.getId() + ", '" + pInfo.getValue()
                + "', '" + pInfo.getDateAdded() + "');";

        return (Database.getInstance().dmlQuery(insertQuery) != 0);
    }

    public boolean renseigne(Consultation con, Allergy allergy) {
        String insertQuery = "INSERT INTO renseigne VALUES("
                +"'"+con.getConsultationId()+"'"
                + ", '"+allergy.getAllergyId()+"');";

        return (Database.getInstance().dmlQuery(insertQuery) != 0);
    }


    public List<Consultation> pendingConsultations() {

        List<Consultation> consultations = new ArrayList<>();
//        PatientDAO patientDAO = DAOFactory.getPatientDAO();
//        PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

        String DayStart = new SimpleDateFormat("yyyy-MM-dd 00:00:00").format(Calendar.getInstance().getTime());
        String DayEnd = new SimpleDateFormat("yyyy-MM-dd 23:59:59").format(Calendar.getInstance().getTime());

        String findAllQuery = "SELECT * "
                + "FROM consultation "
                + "WHERE consultationDate "
                + "BETWEEN '" + DayStart + "' AND '"+ DayEnd + "' ";

        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();
                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                con.setDiagnostics(rs.getString("diagnostics"));
                //con.setPatient(patientDAO.find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
                consultations.add(con);
            }

        } catch (Exception ex) {
            System.out.println("Problem in pendingConsultations - ConsultationDAO " + ex);
        }

        return consultations;
    }

    public List<Consultation> byDate(Timestamp date) {

        List<Consultation> consultations = new ArrayList<>();
//        PatientDAO patientDAO = DAOFactory.getPatientDAO();
//        PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

        String DayStart = new SimpleDateFormat("yyyy-MM-dd 00:00:00").format(date);
        String DayEnd = new SimpleDateFormat("yyyy-MM-dd 23:59:59").format(date);


        String findAllQuery = "SELECT * "
                + "FROM consultation "
                + "WHERE consultationDate "
                + "BETWEEN '" + DayStart + "' AND '"+ DayEnd + "' ";

        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();
                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                con.setDiagnostics(rs.getString("diagnostics"));
                //con.setPatient(patientDAO.find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
                consultations.add(con);
            }

        } catch (Exception ex) {
            System.out.println("Problem in byDate - ConsultationDAO " + ex);
        }

        return consultations;
    }

    public List<Consultation> byHour(String date) {

        List<Consultation> consultations = new ArrayList<>();
//        PatientDAO patientDAO = DAOFactory.getPatientDAO();
//        PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

//        String hour = new SimpleDateFormat("yyyy-MM-dd 00:00:00").format(date);


        String findAllQuery = "SELECT * "
                + "FROM consultation "
                + "WHERE consultationDate = '" + date +"' ";

        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();
                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                con.setDiagnostics(rs.getString("diagnostics"));
                //con.setPatient(patientDAO.find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
                consultations.add(con);
            }

        } catch (Exception ex) {
            System.out.println("Problem in byHour ConsultationDAO " + ex);
        }

        return consultations;
    }

    public List<Consultation> byDate(String date) {

        List<Consultation> consultations = new ArrayList<>();
//        PatientDAO patientDAO = DAOFactory.getPatientDAO();
//        PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

        String DayStart = date + " 00:00:00";
        String DayEnd = date + " 23:59:59";

        String findAllQuery = "SELECT * "
                + "FROM consultation "
                + "WHERE consultationDate "
                + "BETWEEN '" + DayStart + "' AND '"+ DayEnd + "' ";

        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();
                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                con.setDiagnostics(rs.getString("diagnostics"));
                //con.setPatient(patientDAO.find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
                consultations.add(con);
            }

        } catch (Exception ex) {
            System.out.println("Problem in byDate - ConsultationDAO " + ex);
        }

        return consultations;
    }

    public List<Consultation> byDateAndStatus(Timestamp date, String status) {

        List<Consultation> consultations = new ArrayList<>();
//        PatientDAO patientDAO = DAOFactory.getPatientDAO();
//        PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

        String DayStart = new SimpleDateFormat("yyyy-MM-dd 00:00:00").format(date);
        String DayEnd = new SimpleDateFormat("yyyy-MM-dd 23:59:59").format(date);


        String findAllQuery = "SELECT * "
                + "FROM consultation "
                + "WHERE status = '" + status + "' "
                + "AND consultationDate "
                + "BETWEEN '" + DayStart + "' AND '"+ DayEnd + "' ORDER BY consultationDate DESC";

        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();
                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                con.setDiagnostics(rs.getString("diagnostics"));
                //con.setPatient(patientDAO.find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
                consultations.add(con);
            }

        } catch (Exception ex) {
            System.out.println("Problem in byDate - ConsultationDAO " + ex);
        }

        return consultations;
    }


    //finishedConsultations
    public List<Consultation> byStatus(String status) {

        List<Consultation> consultations = new ArrayList<>();

//        PatientDAO patientDAO = DAOFactory.getPatientDAO();
//        PatientInfoDAO patientInfoDAO = DAOFactory.getPatientInfoDAO();

        String findAllQuery = "SELECT * FROM consultation "
                + "WHERE status ='" + status + "';";

        ResultSet rs = Database.getInstance().query(findAllQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();
                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                con.setDiagnostics(rs.getString("diagnostics"));
                //con.setPatient(patientDAO.find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(patientInfoDAO.all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));
                consultations.add(con);
            }

        } catch (Exception ex) {
            System.out.println("Problem in pendingConsultations - ConsultationDAO " + ex);
        }

        return consultations;
    }


    public List<Consultation> all(int patientId) {

        List<Consultation> consultations = new ArrayList<>();

        String findQuery = "SELECT * FROM consultation" ;
        //+ " WHERE id_patient =" + patientId + ";";

        ResultSet rs = Database.getInstance().query(findQuery);

        try {

            while(rs.next()) {

                Consultation con = new Consultation();

                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDiagnostics(rs.getString("diagnostics"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                //con.setPatient(DAOFactory.getPatientDAO().find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                con.setPatientInfoList(DAOFactory.getPatientInfoDAO().all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));

                consultations.add(con);
            }

        } catch (SQLException ex) {
            System.out.println("Error : Consultation.all(int)" + ex);
        }

        return consultations;
    }



    public List<Consultation> like(String like) {

        List<Consultation> consultations = new ArrayList<>();

        String findLikeQuery = "  SELECT consultationId,type,diagnostics,description, consultationDate,status,prix,a.id_patient"+
        " FROM patient a, consultation b";
       //" where a.id_patient=b.id_patient and (prenom_patient like '%" + like + "%' or nom_patient like '%" + like + "%');" ;
        ResultSet rs = Database.getInstance().query(findLikeQuery);

        try {

            while(rs.next()) {
                Consultation con = new Consultation();

                con.setConsultationId(rs.getInt("consultationId"));
                con.setType(rs.getString("type"));
                con.setDiagnostics(rs.getString("diagnostics"));
                con.setDescription(rs.getString("description"));
                con.setConsultationDate(rs.getTimestamp("consultationDate"));
                con.setStatus(rs.getString("status"));
                con.setPrix(rs.getInt("prix"));
                //con.setPatient(DAOFactory.getPatientDAO().find(rs.getString("id_patient")));
                //con.setPatient_FullName(con.getPatient().getName()+" "+ con.getPatient().getLastName());
                con.setDrugList(DAOFactory.getDrugDAO().all(rs.getInt("consultationId")));
                //con.setPatientInfoList(DAOFactory.getPatientInfoDAO().all(rs.getInt("consultationId")));
                con.setAllergyList(DAOFactory.getAllergyDAO().all(rs.getInt("consultationId")));

                consultations.add(con);
            }

        } catch (SQLException ex) {
            System.out.println("Error : Consultation.like(String )" + ex);
        }

        return consultations;
    }



}
