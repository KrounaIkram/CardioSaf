package dashbord.Controllers;

public final class UpdateStatus 
{
    private static boolean isPatientAdded;
    private static boolean isPatientUpdated;

    private static boolean isReservationAdded;
    private static boolean isReservationUpdated;


    public static boolean IsPatientAdded() {
        return isPatientAdded;
    }

    public static void setIsPatientAdded(boolean b) {
        UpdateStatus.isPatientAdded = b;
    }


    public static boolean IsPatientUpdated() {
        return isPatientUpdated;
    }

    public static void setIsPatientUpdated(boolean b) {
        UpdateStatus.isPatientUpdated = b;
    }


    public static boolean isReservationAdded() {
        return isReservationAdded;
    }

    public static void setIsReservationAdded(boolean b) {
        UpdateStatus.isReservationAdded = b;
    }


    public static boolean isReservationUpdated() {
        return isReservationUpdated;
    }

    public static void setIsReservationUpdated(boolean b) {
        UpdateStatus.isReservationUpdated = b;
    }



}
